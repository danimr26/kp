<footer class="footer">
    <div class="container">
     <div class="hidden-xs" align="center">
      [ ] <span></span> KLINIK PERINTIS MEDIKA </div>
    </div>
  </footer>
</body>
</html>