    <script src="<?php echo base_url('assets/js/require.min.js') ?>  "></script>
    <script src="./assets/js/require.min.js"></script>
    <script>
      requirejs.config({
          baseUrl: '.'
      });
    </script>
    <!-- Dashboard Core -->
    <link href="<?php echo base_url('assets/css/dashboard.css') ?>" rel="stylesheet" />
    <script src="<?php echo base_url('assets/js/dashboard.js') ?>"></script>
    <!-- c3.js Charts Plugin -->
    <link href="<?php echo base_url('assets/plugins/charts-c3/plugin.css') ?>" rel="stylesheet" />
    <script src="<?php echo base_url('assets/plugins/charts-c3/plugin.js') ?>"></script>
    <!-- Google Maps Plugin -->
    <link href="<?php echo base_url('assets/plugins/maps-google/plugin.css') ?>" rel="stylesheet" />
    <script src="<?php echo base_url('assets/plugins/maps-google/plugin.js') ?>"></script>
    <!-- Input Mask Plugin -->
    <script src="<?php echo base_url('assets/plugins/input-mask/plugin.js') ?>"></script>